# Curso React Deivchoi

## Instrucciones para ejecutar el proyecto

1. Abrir la terminal
2. Correr los siguientes comandos
   ```
   npm install
   npm run dev
   ```
3. Abrir el link que aparece en la consola
